using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace SyncEkpToCasdoor.Web.Controllers;

[ApiController]
[Route("[controller]")]
public class AuthController : ControllerBase
{
    [HttpGet("/challenge")]
    public new IActionResult Challenge()
    {
        var properties = new AuthenticationProperties
        {
            RedirectUri = "/"
        };
        return base.Challenge(properties, "Casdoor");
    }

    [HttpGet("/logout")]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return Redirect("/login");
    }

    [HttpGet("/callback")]
    public async Task<IActionResult> Callback()
    {
        // OAuth回调处理由中间件自动完成
        // 如果到这里说明认证成功
        var result = await HttpContext.AuthenticateAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        
        if (result?.Succeeded == true)
        {
            return Redirect("/");
        }
        
        return Redirect("/login?error=认证失败");
    }
}
