using SyncEkpToCasdoor.Web.Components;
using SyncEkpToCasdoor.Web.Services;
using SyncEkpToCasdoor.Web.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OAuth;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text.Json;
using Microsoft.AspNetCore.Authentication;

var builder = WebApplication.CreateBuilder(args);

// 配置Casdoor认证设置
var casdoorSettings = builder.Configuration.GetSection("CasdoorAuth").Get<CasdoorSettings>() 
    ?? new CasdoorSettings();

// 添加认证服务
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    options.DefaultSignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = "Casdoor";
})
.AddCookie(options =>
{
    options.LoginPath = "/login";
    options.LogoutPath = "/logout";
    options.AccessDeniedPath = "/access-denied";
    options.ExpireTimeSpan = TimeSpan.FromHours(8);
    options.SlidingExpiration = true;
})
.AddOAuth("Casdoor", options =>
{
    options.ClientId = casdoorSettings.ClientId;
    options.ClientSecret = casdoorSettings.ClientSecret;
    options.CallbackPath = new PathString("/callback");
    
    options.AuthorizationEndpoint = $"{casdoorSettings.Authority}/login/oauth/authorize";
    options.TokenEndpoint = casdoorSettings.TokenEndpoint;
    options.UserInformationEndpoint = casdoorSettings.UserInfoEndpoint;
    
    options.Scope.Add(casdoorSettings.Scope);
    options.SaveTokens = true;
    
    options.ClaimActions.MapJsonKey(ClaimTypes.NameIdentifier, "name");
    options.ClaimActions.MapJsonKey(ClaimTypes.Name, "displayName");
    options.ClaimActions.MapJsonKey(ClaimTypes.Email, "email");
    options.ClaimActions.MapJsonKey("owner", "owner");
    
    options.Events = new OAuthEvents
    {
        OnCreatingTicket = async context =>
        {
            var request = new HttpRequestMessage(HttpMethod.Get, context.Options.UserInformationEndpoint);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", context.AccessToken);
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var response = await context.Backchannel.SendAsync(request, context.HttpContext.RequestAborted);
            response.EnsureSuccessStatusCode();

            var userJson = await response.Content.ReadAsStringAsync();
            var user = JsonSerializer.Deserialize<CasdoorUser>(userJson);

            if (user == null)
            {
                throw new Exception("无法获取用户信息");
            }

            // 验证用户owner必须是built-in
            if (user.Owner != casdoorSettings.AllowedOwner)
            {
                throw new Exception($"访问被拒绝：只允许 {casdoorSettings.AllowedOwner} 用户登录");
            }

            using (var jsonDocument = JsonDocument.Parse(userJson))
            {
                context.RunClaimActions(jsonDocument.RootElement);
            }
            
            // 添加额外的声明
            var identity = (ClaimsIdentity?)context.Principal?.Identity;
            identity?.AddClaim(new Claim("owner", user.Owner));
            identity?.AddClaim(new Claim("access_token", context.AccessToken ?? ""));
        },
        OnRemoteFailure = context =>
        {
            context.Response.Redirect("/login?error=" + Uri.EscapeDataString(context.Failure?.Message ?? "认证失败"));
            context.HandleResponse();
            return Task.CompletedTask;
        }
    };
});

// 添加授权
builder.Services.AddAuthorization();

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// 添加控制器支持
builder.Services.AddControllers();

// 注册同步服务
builder.Services.AddSingleton<ISyncService, SyncService>();

// 添加日志
builder.Services.AddLogging();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
}

// 添加认证和授权中间件
app.UseAuthentication();
app.UseAuthorization();

app.UseAntiforgery();

// 映射控制器路由（必须在 Blazor 路由之前）
app.MapControllers();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
